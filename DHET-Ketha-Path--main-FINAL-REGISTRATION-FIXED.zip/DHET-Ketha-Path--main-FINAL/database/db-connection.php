<?php
/** Khetha Path MySQL connection. Local XAMPP uses plain localhost; production can enable TLS. */
mysqli_report(MYSQLI_REPORT_OFF);

$envFile = __DIR__ . '/.env';
if (is_file($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key); $value = trim($value);
        if (getenv($key) === false) putenv($key . '=' . $value);
    }
}

$isLocal = in_array(strtolower((string)($_SERVER['HTTP_HOST'] ?? '')), ['localhost','127.0.0.1','[::1]'], true)
    || in_array((string)($_SERVER['REMOTE_ADDR'] ?? ''), ['127.0.0.1','::1'], true);

$username = getenv('KHETHA_DB_USER');
$password = getenv('KHETHA_DB_PASSWORD');
$host     = getenv('KHETHA_DB_HOST');
$port     = getenv('KHETHA_DB_PORT') ?: '3306';
$database = getenv('KHETHA_DB_NAME');

// Never read generic Windows/server environment variables such as USERNAME
// or PASSWORD: on local XAMPP, USERNAME may be the Windows machine account.
if ($isLocal) {
    $username = $username !== false && $username !== '' ? $username : 'root';
    $password = $password !== false ? $password : '';
    $host     = $host !== false && $host !== '' ? $host : '127.0.0.1';
    $database = $database !== false && $database !== '' ? $database : 'khetha_path';
} else {
    $username = $username !== false && $username !== '' ? $username : null;
    $password = $password !== false ? $password : null;
    $host     = $host !== false && $host !== '' ? $host : null;
    $database = $database !== false && $database !== '' ? $database : null;
}
$useSSL   = getenv('KHETHA_DB_SSL') === '1' && !$isLocal;

$conn = mysqli_init();
if (!$conn || $username === null || $password === null || $host === null || $database === null) {
    error_log('Khetha DB configuration is incomplete.');
    return;
}

if ($useSSL) {
    $caPath = PHP_OS_FAMILY === 'Windows' ? __DIR__ . '/../isrgrootx1.pem' : '/etc/ssl/certs/ca-certificates.crt';
    $conn->ssl_set(null, null, $caPath, null, null);
}

$flags = $useSSL ? MYSQLI_CLIENT_SSL : 0;
$conn->real_connect($host, $username, $password, $database, (int)$port, null, $flags);
if ($conn->connect_error) error_log('Khetha DB connection failed: ' . $conn->connect_error);
else $conn->set_charset('utf8mb4');
